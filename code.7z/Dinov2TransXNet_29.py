import os
import cv2
import torch
import numpy as np
from tqdm import tqdm

from PIL import Image
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

from sklearn.decomposition import PCA
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import classification_report, confusion_matrix


import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.hub import load_state_dict_from_url
import torch.optim as optim
from torch.optim import lr_scheduler
from torch.utils.data import DataLoader

import torchvision
from torchvision import datasets, models, transforms

import copy

from models.transxnet import transxnet_t
from models.transxnet import transxnet_b
# import timm
# import mmcv

import time


import cv2
import numpy as np
import torch
from torchvision import models
import matplotlib.pyplot as plt
from pytorch_grad_cam import GradCAM
from pytorch_grad_cam import GuidedBackpropReLUModel
from pytorch_grad_cam.utils.image import (
    show_cam_on_image, deprocess_image, preprocess_image
)
from pytorch_grad_cam.utils.model_targets import ClassifierOutputTarget


N = 256
#batch_size = 8
BATCH_SIZE = 20
NUM_WORKERS = 2



RESULTFILE = "Dinov2TransXNet_29_result.txt"
MODEL_WEIGHT_FILE = "Dinov2TransXNet_29_model_weight"

MODEL_WEIGHT = "Dinov2TransXNet_29_model_weight_xx.pth"
best_generation = generation = 0
best_top1_acc = 0.0
num_epochs = 140
learning_rate = 0.00001



projection_dim = 512

num_classes = 500

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

ROOT_PATH = '/data/kami/Food500Dataset'




import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms

data_transforms = {
    'train': transforms.Compose([
        transforms.RandomHorizontalFlip(), # default value is 0.5
        transforms.Resize((N, N)),
        transforms.RandomCrop((224,224)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ]),
     'val': transforms.Compose([
        transforms.Resize((N, N)), 
        transforms.CenterCrop((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ]),
    'test': transforms.Compose([
        transforms.Resize((N, N)),
        transforms.CenterCrop((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ]),
}

image_datasets = {
    x: datasets.ImageFolder(os.path.join(ROOT_PATH, x), data_transforms[x]) 
    for x in ['train', 'val', 'test']
}

data_loaders = {x: DataLoader(image_datasets[x], shuffle=True, batch_size=BATCH_SIZE, num_workers=NUM_WORKERS)
    for x in ['train', 'val', 'test']
}

class_names = image_datasets['train'].classes



class ClusteringLoss(nn.Module):
    def __init__(self, num_clusters, feature_dim, temperature=0.1):
        super(ClusteringLoss, self).__init__()
        self.num_clusters = num_clusters
        self.temperature = temperature
        self.cluster_centers = nn.Parameter(torch.randn(num_clusters, feature_dim))

    def forward(self, features):
        features = F.normalize(features, p=2, dim=1)
        cluster_centers = F.normalize(self.cluster_centers, p=2, dim=1)


        similarity_matrix = torch.matmul(features, cluster_centers.T) / self.temperature
        probs = F.softmax(similarity_matrix, dim=-1)


        with torch.no_grad():
            target = probs.mean(dim=0, keepdim=True).repeat(probs.size(0), 1)

        loss = F.kl_div(probs.log(), target, reduction='batchmean')
        return loss, probs


class CrossAttentionModule(nn.Module):
    def __init__(self, dim_q=672, dim_kv=768, num_heads=8):
        super(CrossAttentionModule, self).__init__()
        self.num_heads = num_heads
        self.head_dim = dim_q // num_heads
        assert dim_q % num_heads == 0 and dim_kv % num_heads == 0, "dim must be divisible by num_heads"

        # 线性变换层用于Q、K、V
        self.q_transform = nn.Conv2d(dim_q, dim_q, kernel_size=1)
        self.kv_transform = nn.Linear(dim_kv, dim_q * 2)

        self.scale = self.head_dim ** -0.5

        self.norm1 = nn.LayerNorm([dim_q, 7, 7], elementwise_affine=False)
        self.norm2 = nn.LayerNorm([dim_q, 7, 7], elementwise_affine=False)
        self.proj_out = nn.Linear(1024, 1024)
        self.mlp = nn.Sequential(
            nn.Conv2d(dim_q, dim_q * 4, kernel_size=1),
            nn.GELU(),
            nn.Conv2d(dim_q * 4, dim_q, kernel_size=1)
        )

    def forward(self, x_q, x_kv):
        B, C, H, W = x_q.shape
        _, N, D = x_kv.shape

        # 对Q进行卷积变换并reshape
        q = self.q_transform(x_q).view(B, self.num_heads, C // self.num_heads, H * W).permute(0, 1, 3,
                                                                                              2)  # [B, H, HW, D//H]

        # 对KV进行线性变换并reshape
        kv = self.kv_transform(x_kv).reshape(B, N, 2, self.num_heads, self.head_dim).permute(2, 0, 3, 1, 4)
        k, v = kv[0], kv[1]  # [B, H, N, D//H]

        # 计算注意力权重
        attn = (q @ k.transpose(-2, -1)) * self.scale  # [B, H, HW, N]
        attn = attn.softmax(dim=-1)

        out = (attn @ v)  # [B, H, HW, D_head]

        # 应用注意力加权求和得到输出
        out = out.transpose(1, 2).reshape(B, H * W, C)  # [B, HW, C]
        out = self.proj_out(out)  # [B, HW, C]

        # 7. Reshape 回图像格式
        out = out.view(B, H, W, C).permute(0, 3, 1, 2)  # [B, C, H, W]

        out = out + x_q
        out = out + self.mlp(self.norm1(out))

        return out




class SelfSupervisedCrossAttention(nn.Module):
    def __init__(self, dim_dino=768, dim_trans=672, projection_dim=1024, num_classes=500, num_clusters=500):
        super(SelfSupervisedCrossAttention, self).__init__()

        # DINOv2 特征提取器
        self.dino_model = torch.hub.load('/data/kami/01_classification/05_Dinov2TransXNet', 'dinov2_vitb14', trust_repo=True,
                                         source='local')
        self.dino_model.load_state_dict(
            torch.load("/data/kami/01_classification/05_Dinov2TransXNet/dinov2_vitb14_pretrain.pth"))


        # TransXNet 特征提取器
        self.transx_model = transxnet_b(pretrained=True)
        self.transx_model.load_state_dict(torch.load("/home/user/.cache/torch/hub/checkpoints/transx-b.pth.tar"))

        # 调整特征维度到相同维度（例如1024）
        self.transx_projection = nn.Conv2d(dim_trans, projection_dim, kernel_size=1)
        self.dino_projection = nn.Linear(dim_dino, projection_dim)


        # 交叉注意力模块
        self.cross_attention = CrossAttentionModule(dim_q=projection_dim, dim_kv=projection_dim, num_heads=8)

        # 融合后处理
        self.fused_projection = nn.Linear(projection_dim, projection_dim)
        self.projection_head = nn.Sequential(
            nn.LayerNorm(projection_dim),
            nn.Linear(projection_dim, projection_dim // 2),
            nn.ReLU()
        )

        # 分类头
        self.classifier = nn.Linear(projection_dim // 2, num_classes)

        # 聚类损失
        self.clustering_loss = ClusteringLoss(num_clusters, projection_dim // 2)

    def forward(self, inputs, labels=None):
        # 提取DINOv2特征
        dino_feats = self.extract_dino_features(inputs)
        dino_feats = self.dino_projection(dino_feats)
        # print(f'dino_feats.shape:{dino_feats.shape}\n')  # 应该是 [20, 256, 1024]

        # 提取TransXNet特征
        trans_feats = self.extract_transx_features(inputs)
        trans_feats = self.transx_projection(trans_feats)

        # 使用交叉注意力进行特征融合
        fused_features = self.cross_attention(trans_feats, dino_feats)

        # 全局平均池化得到分类向量
        pooled_features = F.adaptive_avg_pool2d(fused_features, (1, 1)).flatten(start_dim=1)

        pooled_features = self.projection_head(pooled_features)

        # 分类预测
        logits = self.classifier(pooled_features)
        # print(f'logits.shape:{logits.shape}\n') #[20, 500]

        # 损失计算
        clustering_loss, probs = self.clustering_loss(pooled_features)
        classification_loss = 0
        if labels is not None:
            classification_loss = nn.CrossEntropyLoss()(logits, labels)

        return logits, classification_loss, clustering_loss, probs

    def extract_dino_features(self, x):
        """从DINOv2模型中提取norm层输出"""
        x = self.dino_model.patch_embed(x)

        for blk in self.dino_model.blocks:
            x = blk(x)
        x = self.dino_model.norm(x)
        return x

    def extract_transx_features(self, x):
        x = self.transx_model.patch_embed.proj(x)

        # 前向传播到第一个 ModuleList
        for block in self.transx_model.network[0]:
            x = block(x)

        # 前向传播到第二个 ModuleList
        x = self.transx_model.network[1](x)
        for block in self.transx_model.network[2]:
            x = block(x)

        # 前向传播到第三个 ModuleList
        x = self.transx_model.network[3](x)
        for block in self.transx_model.network[4]:
            x = block(x)

        # 前向传播到最后一个 ModuleList
        x = self.transx_model.network[5](x)
        for block in self.transx_model.network[6]:
            x = block(x)

        return x


import matplotlib.pyplot as plt
from torchvision import transforms
from PIL import Image
import numpy as np




def train_epoch(model, dataloader, criterion, optimizer, device):
    model.train()
    total_loss = 0
    total_classification_loss = 0
    total_clustering_loss = 0
    total_samples = 0

    for inputs, labels in dataloader:
        inputs, labels = inputs.to(device), labels.to(device)

        # # 特征提取
        # dino_feats = dino_model(inputs)
        # trans_feats = transx_model(inputs)

        # 前向传播
        # logits, classification_loss, clustering_loss = model(dino_feats, trans_feats, labels=labels)
        logits, classification_loss, clustering_loss, probs = model(inputs, labels=labels)

        # 总损失 = 分类损失 + 聚类损失
        loss = 0.5*classification_loss + 0.5*clustering_loss
        # loss = classification_loss

        # 反向传播
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        total_loss += loss.item() * labels.size(0)
        total_classification_loss += classification_loss.item() * labels.size(0)
        total_clustering_loss += clustering_loss.item() * labels.size(0)
        total_samples += labels.size(0)

    avg_loss = total_loss / total_samples
    avg_classification_loss = total_classification_loss / total_samples
    avg_clustering_loss = total_clustering_loss / total_samples
    return avg_loss, avg_classification_loss, avg_clustering_loss
    # return avg_loss, avg_classification_loss, 0






import torch
import torch.nn.functional as F
from sklearn.metrics import confusion_matrix
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

def calculate_accuracy(logits, labels):
    # 获取Top-1和Top-5准确率
    _, top1_preds = torch.max(logits, 1)  # Top-1 预测
    # print(f'top1_preds:\n{top1_preds}')
    top5_preds = torch.topk(logits, 5, dim=1).indices  # Top-5 预测
    # print(f'top5_preds:\n{top5_preds}')

    top1_correct = torch.sum(top1_preds == labels).item()  # Top-1 正确预测数
    top5_correct = torch.sum(top5_preds == labels.view(-1, 1)).item()  # Top-5 正确预测数

    return top1_correct, top5_correct






def test_model(model, dataloader, device, num_classes, file_path=RESULTFILE, alpha=0.5):
    model.eval()
    total_top1_correct = 0
    total_top5_correct = 0
    total_samples = 0
    all_labels = []
    all_preds = []
    all_features = []

    with torch.no_grad():
        for inputs, labels in dataloader:
            inputs, labels = inputs.to(device), labels.to(device)

            # 修改点：获取 logits 和 probs
            logits, _, _, probs = model(inputs)

            softmax_logits = F.softmax(logits, dim=1)
            combined_distribution = 0 * probs + 1 * softmax_logits

            # 计算准确率
            top1_correct, top5_correct = calculate_accuracy(combined_distribution, labels)
            total_top1_correct += top1_correct
            total_top5_correct += top5_correct
            total_samples += labels.size(0)

            # 保存标签和预测
            _, preds = torch.max(combined_distribution, 1)
            all_labels.extend(labels.cpu().numpy())
            all_preds.extend(preds.cpu().numpy())

            # 获取融合后的特征
            dino_feats = model.extract_dino_features(inputs)
            dino_feats = model.dino_projection(dino_feats)
            trans_feats = model.extract_transx_features(inputs)
            trans_feats = model.transx_projection(trans_feats)
            fused_features = model.cross_attention(trans_feats, dino_feats)
            pooled_features = F.adaptive_avg_pool2d(fused_features, (1, 1)).flatten(start_dim=1)
            pooled_features = model.projection_head(pooled_features)

            batch_size = inputs.size(0)
            if pooled_features.shape[0] != batch_size or labels.shape[0] != batch_size:
                print("continue\n")
                continue

            # 保存特征和标签
            all_features.extend(pooled_features.cpu().numpy())
            # print(f"\n\n\n\n\nlen(all_features):{len(all_features)},len(all_labels):{len(all_labels)}\n\n\n\n\n")
            assert len(all_features) == len(all_labels)

    # 计算 Top-1 和 Top-5 准确率
    top1_accuracy = total_top1_correct / total_samples
    top5_accuracy = total_top5_correct / total_samples


    # 输出准确率到文件
    with open(file_path, "a") as f:
        f.write(f"Over\t time:{time.ctime()}:\n")
        f.write(f"Top-1 Accuracy: {top1_accuracy:.5f}\n")
        f.write(f"Top-5 Accuracy: {top5_accuracy:.5f}\n\n\n")

    return top1_accuracy, top5_accuracy




import matplotlib.pyplot as plt

import csv

from PIL import ImageFile
ImageFile.LOAD_TRUNCATED_IMAGES = True

def main():

    global best_generation
    global generation
    global best_top1_acc
    
    # 加载数据集
    train_loader = data_loaders['train']
    val_loader = data_loaders['val']
    test_loader = data_loaders['test']

    train_losses = []
    val_top1_acc = []
    val_top5_acc = []

    # 定义模型
    model = SelfSupervisedCrossAttention(dim_dino=768, dim_trans=672,
                                         projection_dim=1024, num_classes=num_classes).to(device)

    if best_generation != 0:
        model.load_state_dict(torch.load(MODEL_WEIGHT))
        with open(RESULTFILE, 'a') as file:
            file.write(f'\n\n\n\n\nload {MODEL_WEIGHT} succeeed\n')


    
    criterion = nn.CrossEntropyLoss()

    # 优化器
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    scheduler = ReduceLROnPlateau(optimizer, mode='max', factor=0.1, patience=10, verbose=True)

    # 类别名称（可选）
    class_names = image_datasets['train'].classes

    best_model_wts = copy.deepcopy(model.state_dict())

    # for name, param in model.named_parameters():
    #     print(f"{name}: requires_grad={param.requires_grad}")

    # 训练和验证
    for epoch in range(num_epochs):
        with open(RESULTFILE, 'a') as file:
            file.write('\nEpoch {}/{}\t current_lr: {}\ttime: {}\n'.format(generation + epoch + 1, generation + num_epochs, optimizer.param_groups[0]['lr'], time.ctime()))
        avg_loss, avg_classification_loss, avg_clustering_loss = train_epoch(model, train_loader, criterion, optimizer, device)
        train_losses.append(avg_loss)

        with open(RESULTFILE, "a") as file:
            file.write('Train avg_loss: {:.5f}\n'.format(avg_loss))
            file.write('Train avg_classification_loss: {:.5f}\n'.format(avg_classification_loss))
            file.write('Train avg_clustering_loss: {:.5f}\n'.format(avg_clustering_loss))

        with open(RESULTFILE, 'a') as file:
            file.write(f"Val start\t time:{time.ctime()}\n")
        top1_accuracy, top5_accuracy = test_model(model, val_loader, device, num_classes)




        # model_weight_file = f'{MODEL_WEIGHT_FILE}_temp_{generation + epoch + 1}.pth'
        # torch.save(model.state_dict(), model_weight_file)

        if best_top1_acc < top1_accuracy:
            best_top1_acc = top1_accuracy
            best_generation = generation + epoch + 1
            best_model_wts = copy.deepcopy(model.state_dict())
            model_weight_file = f'{MODEL_WEIGHT_FILE}_{generation + epoch + 1}.pth'
            torch.save(model.state_dict(), model_weight_file)
            with open(RESULTFILE, "a") as file:
                file.write(f'save {model_weight_file} succeed in epoch: {generation + epoch + 1}\ttime: {time.ctime()}\n')
        else:
            # optimizer.param_groups[0]['lr'] = optimizer.param_groups[0]['lr'] * 0.1
            pass
        scheduler.step(top1_accuracy)



    # model.load_state_dict(best_model_wts)
    with open(RESULTFILE, 'a') as file:
        file.write(f"\n\nTest start\t time:{time.ctime()}\n")
    top1_accuracy, top5_accuracy = test_model(model, test_loader, device, num_classes)





if __name__ == "__main__":
    main()
